package Sistema_Funcionarios;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Listas para armazenar as instâncias
        List<Funcionarios> funcionariosList = new ArrayList<>();
        List<Gerente> gerentesList = new ArrayList<>();
        List<Atendente> atendentesList = new ArrayList<>();

        // Cadastro de Funcionários
        System.out.println("Cadastro de Funcionários:");
        for (int i = 0; i < 3; i++) {
            System.out.println("Funcionário " + (i + 1));
            System.out.print("Nome: ");
            String nome = scanner.nextLine();
            System.out.print("Idade: ");
            int idade = Integer.parseInt(scanner.nextLine());
            System.out.print("CPF: ");
            String cpf = scanner.nextLine();
            System.out.print("Email: ");
            String email = scanner.nextLine();
            System.out.print("Salário: ");
            Float salario = Float.parseFloat(scanner.nextLine());
            System.out.print("Departamento: ");
            String departamento = scanner.nextLine();
            System.out.print("Carga Horária: ");
            int cargaHoraria = Integer.parseInt(scanner.nextLine());

            Funcionarios funcionario = new Funcionarios(nome, idade, cpf, email, salario, departamento, cargaHoraria);
            funcionariosList.add(funcionario);
        }

        // Cadastro de Gerentes
        System.out.println("\nCadastro de Gerentes:");
        for (int i = 0; i < 3; i++) {
            System.out.println("Gerente " + (i + 1));
            System.out.print("Nome: ");
            String nome = scanner.nextLine();
            System.out.print("Idade: ");
            int idade = Integer.parseInt(scanner.nextLine());
            System.out.print("CPF: ");
            String cpf = scanner.nextLine();
            System.out.print("Email: ");
            String email = scanner.nextLine();
            System.out.print("Salário: ");
            Float salario = Float.parseFloat(scanner.nextLine());
            System.out.print("Departamento: ");
            String departamento = scanner.nextLine();
            System.out.print("Carga Horária: ");
            int cargaHoraria = Integer.parseInt(scanner.nextLine());
            System.out.print("Equipe: ");
            String equipe = scanner.nextLine();
            System.out.print("Objetivos: ");
            String objetivos = scanner.nextLine();
            System.out.print("Nível de Gerência: ");
            String nivelGerencia = scanner.nextLine();

            Gerente gerente = new Gerente(nome, idade, cpf, email, salario, departamento, cargaHoraria,
                    equipe, objetivos, null, nivelGerencia);
            gerente.calculaBonusAnual(); // Calcula o bônus anual
            gerentesList.add(gerente);
        }

        // Cadastro de Atendentes
        System.out.println("\nCadastro de Atendentes:");
        for (int i = 0; i < 3; i++) {
            System.out.println("Atendente " + (i + 1));
            System.out.print("Nome: ");
            String nome = scanner.nextLine();
            System.out.print("Idade: ");
            int idade = Integer.parseInt(scanner.nextLine());
            System.out.print("CPF: ");
            String cpf = scanner.nextLine();
            System.out.print("Email: ");
            String email = scanner.nextLine();
            System.out.print("Salário: ");
            Float salario = Float.parseFloat(scanner.nextLine());
            System.out.print("Departamento: ");
            String departamento = scanner.nextLine();
            System.out.print("Carga Horária: ");
            int cargaHoraria = Integer.parseInt(scanner.nextLine());
            System.out.print("ID do Cliente: ");
            String idCliente = scanner.nextLine();
            System.out.print("Número de Atendimentos: ");
            int numeroAtendimentos = Integer.parseInt(scanner.nextLine());
            System.out.print("Meta de Atendimentos: ");
            int metaAtendimentos = Integer.parseInt(scanner.nextLine());

            Atendente atendente = new Atendente(nome, idade, cpf, email, salario, departamento,
                    cargaHoraria, idCliente, numeroAtendimentos,
                    metaAtendimentos, null);

            atendentesList.add(atendente);
        }

        // Mostra informações dos Funcionários
        System.out.println("\nInformações dos Funcionários:");
        for (Funcionarios f : funcionariosList) {
            System.out.println("- Nome: " + f.getNome() + ", Idade: " + f.getIdade() +
                    ", CPF: " + f.getCpf() + ", Salário: " + f.getSalario());
        }

        // Mostra informações dos Gerentes
        System.out.println("\nInformações dos Gerentes:");
        for (Gerente g : gerentesList) {
            System.out.println("- Nome: " + g.getNome() + ", Idade: " + g.getIdade() +
                    ", CPF: " + g.getCpf() + ", Bônus Anual: " + g.calculaBonusAnual());
        }

        // Mostra informações dos Atendentes
        System.out.println("\nInformações dos Atendentes:");
        for (Atendente a : atendentesList) {
            System.out.println("- Nome: " + a.getNome() + ", Idade: " + a.getIdade() +
                    ", CPF: " + a.getCpf() + ", Número de Atendimentos: " + a.getNumeroAtendimentos());
        }

        scanner.close();
    }
}