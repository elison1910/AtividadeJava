package Sistema_Funcionarios;

public class Gerente extends Funcionarios {
    private String equipe;
    private String objetivos;
    private Float bonusAnual;
    private String nivelGerencia;

    // Construtor
    public Gerente(String nome, int idade, String cpf, String email, Float salario, String departamento,
            int cargaHoraria, String equipe, String objetivos, Float bonusAnual, String nivelGerencia) {

        super(nome, idade, cpf, email, salario, departamento, cargaHoraria);
        this.equipe = equipe;
        this.objetivos = objetivos;
        this.bonusAnual = bonusAnual;
        this.nivelGerencia = nivelGerencia;
    }

    // Getters e Setters
    public String getEquipe() {
        return equipe;
    }

    public void setEquipe(String equipe) {
        this.equipe = equipe;
    }

    public String getObjetivos() {
        return objetivos;
    }

    public void setObjetivos(String objetivos) {
        this.objetivos = objetivos;
    }

    public Float getBonusAnual() {
        return bonusAnual;
    }

    public void setBonusAnual(Float bonusAnual) {
        this.bonusAnual = bonusAnual;
    }

    public String getNivelGerencia() {
        return nivelGerencia;
    }

    public void setNivelGerencia(String nivelGerencia) {
        this.nivelGerencia = nivelGerencia;
    }

    // Método para calcular o bônus anual
    public Float calculaBonusAnual() {
        Float percentualBonus;

        switch (nivelGerencia.toLowerCase()) {
            case "junior":
                percentualBonus = 0.05f;
                break;
            case "pleno":
                percentualBonus = 0.10f;
                break;
            case "senior":
                percentualBonus = 0.15f;
                break;
            default:
                percentualBonus = 0.0f;
                break;
        }

        bonusAnual = getSalario() * percentualBonus;

        return bonusAnual;
    }
}